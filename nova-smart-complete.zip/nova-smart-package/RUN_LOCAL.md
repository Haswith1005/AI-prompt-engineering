# Run locally

1. Install Node.js 18+.
2. Open this folder in VS Code.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Vite.

For Netlify, connect the repository and deploy. The `netlify.toml` configures the frontend and Netlify Functions.
