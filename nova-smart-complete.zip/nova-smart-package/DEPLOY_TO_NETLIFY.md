
# GitHub → Netlify

1. Create a GitHub repository, e.g. `nova-cart-smart`.
2. Upload all files in this folder.
3. Netlify → Add new site → Import an existing project → GitHub.
4. Select the repository.
5. Build command: `npm run build`
6. Publish directory: `dist`
7. Deploy.

The Netlify Function is in `netlify/functions/api.mjs`.

For persistent server-side demo records using Netlify Blobs, the deployed site can use Netlify's site identity/runtime. The frontend does not require a secret API key to demonstrate the core workflow.
