# Database

The deployed backend uses Netlify Blobs as the persistence layer for demo orders, refunds and events. No real payment is processed.

Entities represented by the backend:
- orders
- refunds
- events
- delivery/order state

For a production deployment, replace the demo persistence with Supabase/Postgres if relational reporting and authentication are required.
