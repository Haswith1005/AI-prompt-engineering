
import { getStore } from "@netlify/blobs";

const seed = {
  orders: [{id:"NC1024", status:"Out for delivery", total:378}],
  refunds: [{id:"RF2031",orderId:"NC1024",amount:58,status:"PROCESSING",reason:"Product unavailable"}],
  events: []
};

async function db(){
  const store=getStore({name:"nova-cart-demo",siteID:process.env.NETLIFY_SITE_ID,token:process.env.NETLIFY_AUTH_TOKEN});
  return store;
}
async function read(key, fallback){
  try{
    const s=await db(); const v=await s.get(key,{type:"json"}); return v ?? fallback;
  }catch(e){ return fallback; }
}
async function write(key,value){
  try{ const s=await db(); await s.setJSON(key,value); return true; }catch(e){ return false; }
}
export default async (req) => {
  const url=new URL(req.url);
  const path=url.pathname.replace(/^\/.netlify\/functions\/api\/?/,"").replace(/^\/api\/?/,"");
  if(req.method==="GET"){
    if(path==="health") return Response.json({ok:true,service:"NOVA CART API"});
    if(path==="state") return Response.json({
      orders:await read("orders",seed.orders),
      refunds:await read("refunds",seed.refunds),
      events:await read("events",seed.events)
    });
    return Response.json({ok:true,message:"NOVA CART API"});
  }
  if(req.method==="POST"){
    const body=await req.json().catch(()=>({}));
    if(path==="refund"){
      const refunds=await read("refunds",seed.refunds);
      const r={id:body.id||`RF${Date.now().toString().slice(-5)}`,orderId:body.orderId||"NC1024",amount:Number(body.amount||0),status:"PROCESSING",reason:body.reason||"Customer recovery",created:new Date().toISOString()};
      refunds.unshift(r); await write("refunds",refunds);
      return Response.json({ok:true,refund:r});
    }
    if(path==="refund/complete"){
      const refunds=await read("refunds",seed.refunds);
      const r=refunds.find(x=>x.id===body.id);
      if(!r) return Response.json({ok:false,error:"Refund not found"},{status:404});
      r.status="COMPLETED"; await write("refunds",refunds);
      return Response.json({ok:true,refund:r});
    }
    if(path==="event"){
      const events=await read("events",seed.events);
      events.unshift({...body,time:new Date().toISOString()}); await write("events",events);
      return Response.json({ok:true});
    }
  }
  return Response.json({error:"Not found"},{status:404});
};
