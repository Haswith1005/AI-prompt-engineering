# Backend
The production demo API is implemented as a Netlify Function in `netlify/functions/api.mjs`.
It persists orders, refunds and events with Netlify Blobs when deployed on Netlify.

Local frontend fallback state is included so the demo can be shown without credentials.
