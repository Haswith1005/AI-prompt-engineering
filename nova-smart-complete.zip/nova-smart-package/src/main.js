
import { products, stores, demoOrder } from "./data.js";
import "./styles.css";

const state = {
  role: "customer",
  page: "home",
  cart: [],
  order: structuredClone(demoOrder),
  refund: {id:"RF2031", orderId:"NC1024", amount:58, reason:"Product unavailable", status:"PROCESSING", created:"Today, 10:42 AM"},
  unavailable: false,
  delay: false,
  toast: "",
  supportQuery: "",
  search: ""
};

const icons = {GRO:"🥬",PHA:"💊",BAK:"🥐",STA:"📚"};

function money(n){ return "₹" + Number(n).toLocaleString("en-IN"); }
function showToast(msg){ state.toast=msg; render(); setTimeout(()=>{state.toast="";render()},2200); }

function navItems(){
  if(state.role==="customer") return [["home","⌂ Home"],["browse","🛍 Browse"],["orders","📦 Orders"],["support","💬 Support"]];
  if(state.role==="store") return [["store","🏪 Store Dashboard"],["inventory","📦 Inventory"],["orders","🧾 Orders"]];
  if(state.role==="delivery") return [["delivery","🚴 Delivery"],["orders","📦 Orders"]];
  return [["admin","📊 Business Health"],["refunds","💸 Refunds"],["support","💬 Support"]];
}

function layout(content){
  const nav=navItems();
  return `<div class="app">
    <header class="topbar">
      <div class="logo">NOVA<span>CART</span></div>
      <div class="search"><input id="globalSearch" value="${state.search}" placeholder="Search products, stores or help..." /></div>
      <select class="role" id="roleSelect">
        <option value="customer" ${state.role==="customer"?"selected":""}>Customer</option>
        <option value="store" ${state.role==="store"?"selected":""}>Store</option>
        <option value="delivery" ${state.role==="delivery"?"selected":""}>Delivery Partner</option>
        <option value="admin" ${state.role==="admin"?"selected":""}>Admin / Data</option>
      </select>
    </header>
    <div class="layout">
      <aside class="sidebar">
        <div class="navtitle">Workspace</div>
        ${nav.map(([id,label])=>`<button class="navbtn ${state.page===id?"active":""}" data-nav="${id}">${label}</button>`).join("")}
      </aside>
      <main class="main">${content}</main>
    </div>
    ${state.toast?`<div class="toast">✓ ${state.toast}</div>`:""}
    ${state.cart.length?`<div class="cartbar"><span>🛒 ${state.cart.length} item${state.cart.length>1?"s":""} · ${money(state.cart.reduce((s,p)=>s+p.price,0))}</span><button data-action="checkout">View cart →</button></div>`:""}
  </div>`;
}

function hero(){
 return `<section class="hero">
   <div><div class="hero-badge">AI-powered local commerce recovery</div><h1>Predict. Prevent. Recover.</h1>
   <p>NOVA CART connects customers, stores and delivery operations to prevent avoidable failures and automatically recover when things go wrong.</p></div>
   <div style="min-width:210px;align-self:center"><div style="font-size:12px;color:#bfe4df">TODAY'S EXPERIENCE</div><div style="font:800 27px 'Plus Jakarta Sans'">Reliable local shopping</div><div style="margin-top:8px;font-size:12px;color:#d6eeea">Availability confidence · smart ETA · refund recovery</div></div>
 </section>`;
}

function customerHome(){
 const cats=[["GRO","🥬","Groceries"],["PHA","💊","Pharmacy"],["BAK","🥐","Bakery"],["STA","📚","Stationery"]];
 const rec=products.filter(p=>p.confidence>=94).slice(0,8);
 return hero()+`
 <section class="section"><div class="sectionhead"><h2>Shop local categories</h2><span class="muted">620 stores · local-first</span></div>
 <div class="grid">${cats.map(c=>`<button class="panel" style="text-align:left" data-cat="${c[0]}"><div style="font-size:32px">${c[1]}</div><b style="display:block;margin-top:10px">${c[2]}</b><small class="muted">12 products available</small></button>`).join("")}</div></section>
 <section class="section"><div class="sectionhead"><h2>Available near you</h2><span class="muted">Inventory confidence shown before you order</span></div>${productGrid(rec)}</section>
 <section class="section two">
   <div class="panel"><div class="sectionhead"><h2>Why NOVA SMART?</h2></div>
    <div class="row"><span>✓ Availability confidence</span><span class="status ok">Prevent</span></div>
    <div class="row"><span>✓ Delivery risk alerts</span><span class="status info">Predict</span></div>
    <div class="row"><span>✓ Automatic refund tracking</span><span class="status ok">Recover</span></div>
    <div class="row"><span>✓ Context-aware support</span><span class="status ok">Resolve</span></div>
   </div>
   <div class="panel"><h2 style="margin-top:0">Demo scenario</h2><p class="muted">Try the working recovery journey from Orders: simulate an unavailable product, choose a refund, then check Support.</p><button class="primary" data-nav="orders">Open demo order →</button></div>
 </section>`;
}

function productGrid(list){
 if(!list.length) return `<div class="empty">No products match your search.</div>`;
 return `<div class="grid">${list.map(p=>`
 <article class="product">
   <div class="pvisual">${icons[p.category]}</div>
   <div class="pbody"><span class="tag">${p.subcategory}</span><div class="pname">${p.name}</div><div class="brand">${p.brand} · ${p.store}</div>
   <div class="price">${money(p.price)}</div><div class="confidence">● ${p.confidence}% availability confidence · ${p.eta}</div>
   <div class="pactions"><button class="primary" data-add="${p.id}">Add</button><button class="secondary" data-buy="${p.id}">Buy</button></div></div>
 </article>`).join("")}</div>`;
}

function browse(){
 let list=products;
 if(state.search) list=list.filter(p=>(p.name+" "+p.brand+" "+p.store+" "+p.subcategory).toLowerCase().includes(state.search.toLowerCase()));
 return `<div class="sectionhead"><div><h2>Local catalogue</h2><span class="muted">48 products · 12 in every category</span></div><button class="secondary" data-nav="home">← Home</button></div>
 <div class="grid" style="margin-bottom:18px">${[["GRO","🥬","Groceries"],["PHA","💊","Pharmacy"],["BAK","🥐","Bakery"],["STA","📚","Stationery"]].map(c=>`<button class="secondary" data-cat="${c[0]}">${c[1]} ${c[2]}</button>`).join("")}</div>
 ${productGrid(list)}`;
}

function orders(){
 const o=state.order;
 return `<div class="sectionhead"><div><h2>Order #${o.id}</h2><span class="muted">The end-to-end recovery demo</span></div><span class="status ${state.unavailable?"warn":"ok"}">${state.unavailable?"ACTION NEEDED":"ON TRACK"}</span></div>
 <div class="two">
  <div>
   ${state.unavailable?`<div class="alert"><b>⚠ Product unavailable</b><br>Milk became unavailable after ordering. NOVA SMART detected the failure and opened recovery options instead of leaving the customer stuck.</div>`:""}
   <div class="panel"><h3 style="margin-top:0">Items</h3>
   ${o.items.map((x,i)=>`<div class="row"><span>${x.name} × ${x.qty}</span><b>${money(x.price*x.qty)}</b></div>`).join("")}
   <div class="row"><span>Delivery</span><b>${money(o.delivery)}</b></div><div class="row"><strong>Total</strong><strong>${money(o.total)}</strong></div>
   </div>
   <div class="panel" style="margin-top:18px"><div class="sectionhead"><h3 style="margin:0">Smart delivery tracking</h3><span class="status ${state.delay?"warn":"ok"}">${state.delay?"DELAY RISK":"LOW RISK"}</span></div>
   ${timeline(state.delay)}
   ${state.delay?`<div class="alert"><b>Delay detected:</b> predicted delay is 17 minutes. Customer notification and recovery eligibility are triggered automatically.</div>`:""}
   <div class="pactions"><button class="amber" data-action="delay">${state.delay?"Clear simulated delay":"Simulate 17-min delay"}</button><button class="secondary" data-action="notify">Notify customer</button></div>
   </div>
  </div>
  <div>
   ${state.unavailable?recoveryCard():demoControls()}
   ${state.refund?refundCard():""}
  </div>
 </div>`;
}
function timeline(delay){
 return `<div class="timeline"><div class="dot"></div><div><b>Store accepted</b><small>10:08 AM · order confirmed</small></div></div>
 <div class="timeline"><div class="dot"></div><div><b>Preparing order</b><small>10:13 AM · store preparing</small></div></div>
 <div class="timeline"><div class="dot ${delay?"off":""}"></div><div><b>Out for delivery</b><small>ETA ${delay?"45–51":"28–34"} min · live status</small></div></div>
 <div class="timeline"><div class="dot off"></div><div><b>Delivered</b><small>Pending</small></div></div>`;
}
function demoControls(){
 return `<div class="panel"><h3 style="margin-top:0">Judge demo controls</h3><p class="muted">Create the failure intentionally and show how NOVA SMART recovers without a support queue.</p>
 <button class="danger" data-action="unavailable">Simulate product unavailable</button>
 <div style="margin-top:14px;font-size:12px;color:var(--muted)">This is a simulated business event for the prototype; no real payment is processed.</div></div>`;
}
function recoveryCard(){
 return `<div class="panel"><h3 style="margin-top:0">Choose your recovery</h3><p class="muted">You keep control. The system handles the workflow.</p>
 <button class="secondary" style="width:100%;margin-bottom:9px" data-action="replace">↻ Replace with similar product</button>
 <button class="primary" style="width:100%;margin-bottom:9px" data-action="refund">₹ Remove item & refund ₹58</button>
 <button class="danger" style="width:100%" data-action="cancel">Cancel order & refund</button>
 </div>`;
}
function refundCard(){
 return `<div class="refund" style="margin-top:16px"><div class="sectionhead"><div><b>Refund ${state.refund.id}</b><div class="muted" style="font-size:12px">${state.refund.reason}</div></div><span class="status ${state.refund.status==="COMPLETED"?"ok":"warn"}">${state.refund.status}</span></div>
 <div class="amount">${money(state.refund.amount)}</div>
 <div class="muted" style="font-size:12px">Order #${state.refund.orderId} · Created ${state.refund.created}</div>
 <div style="margin-top:13px">${refundTimeline()}</div>
 <button class="secondary" data-nav="support">Ask support about refund →</button>
 </div>`;
}
function refundTimeline(){
 const done=state.refund.status==="COMPLETED";
 return `<div class="timeline"><div class="dot"></div><div><b>Refund requested</b><small>Automatic recovery created</small></div></div>
 <div class="timeline"><div class="dot"></div><div><b>Payment gateway notified</b><small>Refund record linked to order</small></div></div>
 <div class="timeline"><div class="dot ${done?"":"off"}"></div><div><b>Refund completed</b><small>${done?"Completed successfully":"Waiting for processing"}</small></div></div>`;
}

function support(){
 return `<div class="sectionhead"><div><h2>Customer Support</h2><span class="muted">Context-aware — no need to repeat your order details</span></div></div>
 <div class="two"><div class="panel"><h3 style="margin-top:0">How can we help?</h3>
 ${["Where is my refund?","Where is my order?","My item is missing","Product became unavailable","Wrong item received","Coupon problem"].map(q=>`<button class="secondary" style="margin:4px;width:calc(50% - 10px);text-align:left" data-support="${q}">${q}</button>`).join("")}
 <div style="margin-top:16px"><input id="supportInput" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px" placeholder="Ask about your order or refund..." value="${state.supportQuery}"></div>
 <button class="primary" style="margin-top:10px" data-action="supportAsk">Get instant answer</button>
 </div>
 <div class="panel">${supportAnswer()}</div></div>`;
}
function supportAnswer(){
 const q=state.supportQuery.toLowerCase();
 if(q.includes("refund") || state.refund){
   return `<div class="tag">LIVE ORDER CONTEXT</div><h3>Refund ${state.refund.id}</h3><p>Your refund for <b>${money(state.refund.amount)}</b> is linked to order <b>#${state.refund.orderId}</b>.</p><div class="refund"><b>Status: ${state.refund.status}</b><br><span class="muted">${state.refund.status==="COMPLETED"?"The refund has completed.":"The refund is processing; you don't need to open another ticket."}</span></div>`;
 }
 if(q.includes("order")) return `<div class="tag">LIVE ORDER CONTEXT</div><h3>Order #${state.order.id}</h3><p>Current status: <b>${state.order.status}</b>. Estimated delivery: <b>${state.delay?"45–51":"28–34"} minutes</b>.</p>`;
 return `<div class="empty"><div style="font-size:36px">💬</div><p>Select a common issue or ask a question. The prototype uses order/refund context to answer instantly.</p></div>`;
}

function store(){
 return `<div class="sectionhead"><div><h2>Store Command Center</h2><span class="muted">Designed to reduce catalogue effort and rejected orders</span></div><span class="status ok">STORE HEALTH: GOOD</span></div>
 <div class="kpis"><div class="kpi"><div class="label">Today's orders</div><div class="value">47</div><div class="positive">+8% vs avg</div></div><div class="kpi"><div class="label">Acceptance rate</div><div class="value">94%</div><div class="positive">+3 pts</div></div><div class="kpi"><div class="label">Inventory accuracy</div><div class="value">91%</div><div class="delta">⚠ Target 95%</div></div><div class="kpi"><div class="label">Avg preparation</div><div class="value">8m</div><div class="positive">2m faster</div></div></div>
 <div class="two section"><div class="panel"><div class="sectionhead"><h3 style="margin:0">Inventory risk</h3><button class="secondary" data-nav="inventory">Manage inventory</button></div>
 ${products.filter(p=>p.category==="GRO").slice(0,7).map((p,i)=>`<div class="row"><span>${p.name}</span><span class="status ${p.confidence<90?"warn":"ok"}">${p.confidence}% confidence</span></div>`).join("")}
 </div><div class="panel"><h3 style="margin-top:0">Store actions</h3><button class="primary" style="width:100%;margin-bottom:9px" data-action="busy">Toggle busy mode</button><button class="secondary" style="width:100%" data-action="accept">Accept queued orders</button><p class="muted" style="font-size:12px;margin-top:15px">Busy mode helps prevent avoidable rejection during peak periods by communicating capacity.</p></div></div>`;
}
function inventory(){
 const list=products.filter(p=>p.category==="GRO");
 return `<div class="sectionhead"><div><h2>Smart Inventory</h2><span class="muted">Confidence replaces blind “in stock” claims</span></div><button class="secondary" data-nav="store">← Store</button></div>
 <div class="panel"><table class="table"><thead><tr><th>Product</th><th>Store</th><th>Confidence</th><th>Risk</th><th>Action</th></tr></thead><tbody>
 ${list.map(p=>`<tr><td><b>${p.name}</b><br><small class="muted">${p.brand}</small></td><td>${p.store}</td><td>${p.confidence}%</td><td><span class="status ${p.confidence<90?"warn":"ok"}">${p.confidence<90?"CHECK STOCK":"HEALTHY"}</span></td><td><button class="secondary" data-inventory="${p.id}">Update</button></td></tr>`).join("")}
 </tbody></table></div>`;
}

function delivery(){
 return `<div class="sectionhead"><div><h2>Delivery Partner Console</h2><span class="muted">Risk-aware delivery workflow</span></div><span class="status ${state.delay?"warn":"ok"}">${state.delay?"DELAY RISK":"LOW RISK"}</span></div>
 <div class="kpis"><div class="kpi"><div class="label">Active tasks</div><div class="value">4</div></div><div class="kpi"><div class="label">Avg pickup</div><div class="value">7m</div></div><div class="kpi"><div class="label">On-time rate</div><div class="value">87%</div></div><div class="kpi"><div class="label">Risk alerts</div><div class="value">${state.delay?"1":"0"}</div></div></div>
 <div class="two section"><div class="panel"><h3 style="margin-top:0">Active #${state.order.id}</h3>${timeline(state.delay)}<button class="amber" data-action="delay">${state.delay?"Clear delay":"Simulate delay risk"}</button></div><div class="panel"><h3 style="margin-top:0">Workload</h3><div class="chartrow"><span>Current</span><div class="bar"><span style="width:68%"></span></div><b>68%</b></div><div class="chartrow"><span>Peak forecast</span><div class="bar"><span style="width:84%"></span></div><b>84%</b></div><p class="muted" style="font-size:12px">The system can flag capacity before accepting additional orders.</p></div></div>`;
}

function admin(){
 return `<div class="sectionhead"><div><h2>Business Health</h2><span class="muted">Evidence → insight → intervention</span></div><span class="status info">NOVA SMART CONTROL TOWER</span></div>
 <div class="kpis"><div class="kpi"><div class="label">Monthly orders</div><div class="value">38,500</div><div class="positive">↑ from 31,200</div></div><div class="kpi"><div class="label">Repeat purchase</div><div class="value">27%</div><div class="delta">↓ from 41%</div></div><div class="kpi"><div class="label">Avg delivery</div><div class="value">37m</div><div class="delta">↑ from 29m</div></div><div class="kpi"><div class="label">Cancellations</div><div class="value">11%</div><div class="delta">↑ from 6%</div></div></div>
 <div class="two section"><div class="panel"><div class="sectionhead"><h3 style="margin:0">Failure signals</h3><span class="muted">Current case data</span></div>
 ${[["Product unavailable",35],["Customer cancelled due to delay",27],["Store rejected order",18],["Delivery partner unavailable",12]].map(x=>`<div class="chartrow"><span>${x[0]}</span><div class="bar"><span style="width:${x[1]*2.2}%"></span></div><b>${x[1]}%</b></div>`).join("")}
 </div><div class="panel"><h3 style="margin-top:0">Support load</h3>${[["Refund status",29],["Delayed delivery",24],["Missing product",19],["Coupon problem",13]].map(x=>`<div class="chartrow"><span>${x[0]}</span><div class="bar"><span style="width:${x[1]*2.6}%"></span></div><b>${x[1]}%</b></div>`).join("")}</div></div>
 <div class="three section"><div class="panel"><div class="tag">PREVENT</div><h3>Inventory confidence</h3><p class="muted">Show customers a confidence signal and alert stores before high-risk stock fails.</p></div><div class="panel"><div class="tag">PREDICT</div><h3>Delivery risk</h3><p class="muted">Detect a 15+ minute delay risk and notify the customer before a complaint.</p></div><div class="panel"><div class="tag">RECOVER</div><h3>Refund automation</h3><p class="muted">Link order → reason → refund → support so customers don't chase status updates.</p></div></div>
 <div class="panel section"><h3 style="margin-top:0">Prototype impact dashboard</h3><table class="table"><thead><tr><th>Intervention</th><th>Current pain</th><th>Prototype response</th><th>Measure</th></tr></thead><tbody>
 <tr><td>Inventory confidence</td><td>35% of cancellations from unavailable products</td><td>Confidence + store risk alerts</td><td>Cancellation rate</td></tr>
 <tr><td>Delay recovery</td><td>27% of cancellations from delay</td><td>Risk alert + customer recovery</td><td>Late/cancelled orders</td></tr>
 <tr><td>Refund center</td><td>29% of tickets are refund status</td><td>Automatic linked refund timeline</td><td>Support tickets / resolution time</td></tr>
 <tr><td>Partner workload</td><td>39% say inventory maintenance is difficult</td><td>Simple inventory risk view</td><td>Inventory accuracy / effort</td></tr>
 </tbody></table></div>`;
}
function refunds(){
 return `<div class="sectionhead"><div><h2>Refund Control Center</h2><span class="muted">Every refund is connected to an order and reason</span></div></div>
 <div class="panel"><table class="table"><thead><tr><th>Refund</th><th>Order</th><th>Amount</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead><tbody>
 <tr><td><b>${state.refund.id}</b></td><td>${state.refund.orderId}</td><td>${money(state.refund.amount)}</td><td>${state.refund.reason}</td><td><span class="status ${state.refund.status==="COMPLETED"?"ok":"warn"}">${state.refund.status}</span></td><td>${state.refund.status==="COMPLETED"?"—":`<button class="primary" data-action="completeRefund">Complete demo refund</button>`}</td></tr>
 <tr><td>RF2029</td><td>NC1021</td><td>₹120</td><td>Wrong item</td><td><span class="status ok">COMPLETED</span></td><td>—</td></tr>
 <tr><td>RF2027</td><td>NC1017</td><td>₹45</td><td>Unavailable</td><td><span class="status ok">COMPLETED</span></td><td>—</td></tr>
 </tbody></table></div>`;
}

function page(){
 if(state.role==="customer"){
  if(state.page==="home") return customerHome();
  if(state.page==="browse") return browse();
  if(state.page==="orders") return orders();
  if(state.page==="support") return support();
 }
 if(state.role==="store"){
  if(state.page==="inventory") return inventory();
  return store();
 }
 if(state.role==="delivery") return delivery();
 if(state.role==="admin"){
  if(state.page==="refunds") return refunds();
  if(state.page==="support") return support();
  return admin();
 }
 return customerHome();
}

function render(){ document.querySelector("#app").innerHTML=layout(page()); bind(); }

function bind(){
 document.querySelectorAll("[data-nav]").forEach(b=>b.onclick=()=>{state.page=b.dataset.nav;render()});
 document.querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{state.search="";state.page="browse";render();setTimeout(()=>{const inp=document.querySelector("#globalSearch"); if(inp){state.search=b.dataset.cat==="GRO"?"":""}},0)});
 document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>{const p=products.find(x=>x.id===b.dataset.add);state.cart.push(p);showToast(`${p.name} added to cart`)});
 document.querySelectorAll("[data-buy]").forEach(b=>b.onclick=()=>{const p=products.find(x=>x.id===b.dataset.buy);state.cart=[p];showToast("Product added — checkout ready")});
 const role=document.querySelector("#roleSelect"); if(role) role.onchange=()=>{state.role=role.value;state.page=state.role==="customer"?"home":state.role==="admin"?"admin":state.role==="delivery"?"delivery":"store";render()};
 const search=document.querySelector("#globalSearch"); if(search){search.oninput=e=>{state.search=e.target.value;if(state.role==="customer"){state.page="browse";render()}}}
 document.querySelectorAll("[data-support]").forEach(b=>b.onclick=()=>{state.supportQuery=b.dataset.support;render()});
 const si=document.querySelector("#supportInput"); if(si) si.oninput=e=>state.supportQuery=e.target.value;
 document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>action(b.dataset.action));
 document.querySelectorAll("[data-inventory]").forEach(b=>b.onclick=()=>showToast("Inventory updated — confidence recalculated"));
}
function action(a){
 if(a==="unavailable"){state.unavailable=true;state.page="orders";showToast("Inventory failure detected — recovery opened")}
 if(a==="refund"){state.unavailable=true;state.refund.status="PROCESSING";showToast("₹58 refund initiated")}
 if(a==="completeRefund"){state.refund.status="COMPLETED";showToast("Demo refund marked completed")}
 if(a==="delay"){state.delay=!state.delay;showToast(state.delay?"17-minute delay risk detected":"Delay risk cleared")}
 if(a==="notify"){showToast("Customer notification sent")}
 if(a==="replace"){state.unavailable=false;showToast("Similar item selected — order continues")}
 if(a==="cancel"){state.refund.amount=349;state.refund.reason="Order cancelled";state.refund.status="PROCESSING";showToast("Cancellation + refund created")}
 if(a==="supportAsk"){state.supportQuery=document.querySelector("#supportInput")?.value||"Where is my refund?";render();return}
 if(a==="checkout"){showToast("Demo checkout: payment simulated");state.cart=[]}
 if(a==="busy"){showToast("Busy mode enabled — new orders capped")}
 if(a==="accept"){showToast("Queued orders accepted")}
 render();
}

render();
