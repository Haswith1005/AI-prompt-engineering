
# NOVA CART — Complete Hackathon Prototype A

## Product
**NOVA SMART — Predict. Prevent. Recover.**

This prototype is built around the NOVA CART challenge evidence:
- repeat purchase fell 41% → 27%
- average delivery rose 29 → 37 minutes
- cancellation rose 6% → 11%
- 35% of cancellations are product-unavailable
- 27% are customer cancellations because of delay
- 29% of support tickets are refund-status questions
- support resolution averages 9.2 hours
- 39% of partner stores say online inventory maintenance requires too much effort

## What is functional
### Customer
- Browse 48 products (12 each: groceries, pharmacy, bakery, stationery)
- Search
- Availability-confidence display
- Add/buy
- Demo order tracking
- Simulate unavailable item
- Choose replace / refund / cancel
- Refund timeline
- Delivery-delay simulation
- Context-aware support

### Store
- Store KPI dashboard
- Inventory risk table
- Inventory update interaction
- Busy-mode / order acceptance demo

### Delivery Partner
- Active delivery
- ETA and risk status
- Delay simulation
- Workload view

### Admin / Data
- Business KPI dashboard
- Failure analysis
- Support-load analysis
- Intervention → pain → response → measure table
- Refund control center

## Backend + database
`netlify/functions/api.mjs` is a real serverless API.

When deployed on Netlify with Netlify Blobs available, it persists:
- orders
- refunds
- events

The frontend is deliberately usable without credentials for the 2-hour hackathon demo; the visible demo state is client-side so the presentation does not break if backend credentials are missing.

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Netlify
Push this folder to GitHub and import the repository into Netlify.

Build command:
`npm run build`

Publish directory:
`dist`

Netlify Functions:
`netlify/functions`

## Judge demo
1. Open Customer.
2. Go to Orders.
3. Click **Simulate product unavailable**.
4. Click **Remove item & refund ₹58**.
5. Open Support.
6. Show that support already knows refund ID, order ID, amount and status.
7. Switch to Admin.
8. Open Refunds.
9. Click **Complete demo refund**.
10. Return to Customer → Orders → show COMPLETED.

## Important
The refund is a simulation. No real money is moved.
The prototype is designed to demonstrate the workflow and business logic, not production payment processing.

## Business story
Prevent:
- inventory surprises

Predict:
- delivery risk

Recover:
- refunds and customer support

The intended measurable outcomes are lower cancellation/support friction, faster refund resolution, better inventory accuracy and improved retention.
